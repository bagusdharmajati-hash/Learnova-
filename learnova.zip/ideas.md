# Arah desain Learnova

## Acuan utama
Replika dashboard belajar pada https://learnova-hzxcgypc.manus.space/ adalah spesifikasi visual utama. Pertahankan merek Learnova, palet lavender–ungu di atas kanvas putih, hierarki tiga kolom, ilustrasi/foto pelajar pada hero, dan naskah berbahasa Indonesia. Jangan menggantinya dengan arah estetika baru.

## Sistem visual
- **Gerakan desain:** dashboard editorial pendidikan yang ringan dan hangat, dengan komposisi modular.
- **Prinsip:** mudah dipindai, lapang, progres belajar terasa memotivasi, tindakan utama jelas.
- **Warna:** putih/off-white sebagai latar; ungu lembut untuk tombol, garis progres dan aksen; hijau/mint sebagai sinyal pencapaian; jingga untuk semangat/streak; teks arang.
- **Tata letak:** sidebar kiri tetap, kolom utama fleksibel, panel kanan ringkas; berubah menjadi drawer dan panel bertumpuk pada layar sempit.
- **Ciri khas:** hero lavender dengan heading serif miring, fotografi dalam sudut bundar, kartu kursus dengan bidang warna pastel, ring progres dan grafik aktivitas mini.
- **Interaksi:** respons langsung untuk navigasi, cari, buka materi, kuis dan target; penyimpanan data demo melalui API, bukan pura-pura masuk Google atau mengklaim tutor AI aktif.
- **Animasi:** hover dan transisi halus 150–250 ms, dengan dukungan reduced motion.
- **Tipografi:** sans modern untuk UI dan heading utama, serif kontras untuk frasa editorial di hero; penanda bagian uppercase berjarak.
- **Esensi merek:** belajar dengan arah yang lembut dan percaya diri. Suara merek menyemangati tanpa berlebihan.
- **Logo:** simbol topi wisuda sederhana pada bidang lavender, wordmark lowercase `learnova.` dengan titik ungu; dipakai konsisten di sidebar dan favicon.
- **Warna khas:** ungu Learnova, sekitar #7463d5, disesuaikan dengan detail referensi.

## Aset
Foto hero gunakan foto pelajar laptop yang tampil pada referensi publik, sehingga objek dan komposisinya setia. Logo/ikon proyek digambar sebagai PNG persegi penuh dengan latar lavender, simbol topi wisuda yang terbaca pada ukuran kecil.
